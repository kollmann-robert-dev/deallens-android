# DealLens Android App – Backend-Anbindung

Dieses Projekt bindet die Android-App direkt an das FastAPI-Backend an, das wir zuvor erstellt haben.

## Enthalten
- Jetpack Compose UI
- Retrofit API-Client
- Repository + ViewModel
- Scan-Demo: sendet erkannte Produkte an `/scan/match`
- Bestpreis-Suche über `/offers/best`
- Produktsuche über `/products/search`

## Backend-URL anpassen
Öffne:

`app/src/main/java/com/deallens/data/network/ApiClient.kt`

und ändere `BASE_URL`.

### Emulator
- Android Emulator zu lokalem Rechner: `http://10.0.2.2:8000/`

### Echtes Gerät im gleichen WLAN
- Beispiel: `http://192.168.1.55:8000/`

## AndroidManifest
Für HTTP im lokalen Netzwerk ist `usesCleartextTraffic=true` gesetzt.

## Start
1. Projekt in Android Studio öffnen
2. Gradle sync ausführen
3. Backend starten
4. App ausführen

## Wichtige Screens
- HomeScreen: Produktsuche
- ScanScreen: Demo-Scan für Prospektprodukte
- ResultScreen: Treffer + Bestpreise

## Nächste Ausbaustufen
- Kamera + OCR mit ML Kit
- Barcode-Scanner
- echte Bildanalyse statt Demo-Scan
- Paging / Caching / Room


## Sofort nutzbar
Diese Version hat jetzt einen eingebauten Offline-Demo-Modus. Auch ohne laufendes Backend kannst du Suche, Bestpreis und Scan-Flow direkt testen.

## Handy-only APK Build
Im Ordner `.github/workflows/android-debug-apk.yml` ist ein GitHub-Actions-Workflow enthalten. Damit kannst du das Projekt in GitHub hochladen und die APK im Browser bauen lassen.
